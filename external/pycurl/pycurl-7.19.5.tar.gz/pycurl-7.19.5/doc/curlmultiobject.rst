.. _curlmultiobject:

CurlMulti Object
================

.. autoclass:: pycurl.CurlMulti

    CurlMulti objects have the following methods:
    
    .. automethod:: pycurl.CurlMulti.close

    .. automethod:: pycurl.CurlMulti.add_handle

    .. automethod:: pycurl.CurlMulti.remove_handle

    .. automethod:: pycurl.CurlMulti.perform

    .. automethod:: pycurl.CurlMulti.fdset

    .. automethod:: pycurl.CurlMulti.select

    .. automethod:: pycurl.CurlMulti.info_read
