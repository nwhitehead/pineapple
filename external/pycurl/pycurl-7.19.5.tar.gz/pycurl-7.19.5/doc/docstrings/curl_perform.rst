perform() -> None

Perform a file transfer.

Corresponds to `curl_easy_perform`_ in libcurl.

Raises pycurl.error exception upon failure.

.. _curl_easy_perform:
    http://curl.haxx.se/libcurl/c/curl_easy_perform.html
